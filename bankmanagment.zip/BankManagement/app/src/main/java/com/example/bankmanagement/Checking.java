package com.example.bankmanagement;

import android.view.MenuItem;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Checking extends AppCompatActivity {
TableLayout tableLayout;
    @Override
    public void onBackPressed() {
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checking);
        tableLayout=findViewById(R.id.table);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        /* Create a Button to be the row-content. */
        for (Operation op:MainActivity.list){
            TableRow tr = new TableRow(this);

            tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            tr.setBackgroundResource(R.drawable.border);
            TextView textView=new TextView(this);
            textView.setTextSize(20);
            textView.setBackgroundResource(R.drawable.border);
            textView.setText(""+op.getNum());
            textView.setWidth(100);
            TextView textView1=new TextView(this);
            textView1.setText(""+op.getAmount());
            textView1.setWidth(100);
            textView1.setBackgroundResource(R.drawable.border);
            textView1.setTextSize(20);


            TextView textView2=new TextView(this);
            textView2.setText(""+op.getDatetime());
            textView2.setWidth(200);
            textView2.setTextSize(20);

            tr.addView(textView);tr.addView(textView1);tr.addView(textView2);

            tableLayout.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));


        }
        /* Add Button to row. */
        /* Add row to TableLayout. */
//tr.setBackgroundResource(R.drawable.sf_gradient_03);
    }
}

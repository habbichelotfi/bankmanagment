package com.example.bankmanagement;

import android.icu.util.LocaleData;

import java.time.LocalDate;
import java.util.Date;

public class Operation {
    int num;
    double amount;
    LocalDate datetime;

    public Operation(int num, double amount, LocalDate datetime) {
        this.num = num;
        this.amount = amount;
        this.datetime = datetime;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDate getDatetime() {
        return datetime;
    }

    public void setDatetime(LocalDate datetime) {
        this.datetime = datetime;
    }
}

package com.example.bankmanagement;

import android.content.Intent;
import android.graphics.Path;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
Button checking,transfer,quiter;
static List<Operation> list=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checking=findViewById(R.id.cheking);
        transfer=findViewById(R.id.transfer);
        quiter=findViewById(R.id.quiter);
        quiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
         list=new ArrayList<>();

        list.add(new Operation(1,1000,LocalDate.of(2020,12,11)));
        list.add(new Operation(2,-500,LocalDate.of(2020,12,12)));
        list.add(new Operation(3,-300,LocalDate.of(2020,12,13)));

        checking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
Intent intent=new Intent().setClass(MainActivity.this,Checking.class);
startActivity(intent);

            }
        });

        transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent().setClass(MainActivity.this,Transfer.class);
                startActivity(intent);

            }
        });
    }
}

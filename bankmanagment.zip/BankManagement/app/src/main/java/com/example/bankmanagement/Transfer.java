package com.example.bankmanagement;

import android.content.DialogInterface;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.time.LocalDate;
import java.util.Objects;

public class Transfer extends AppCompatActivity {
TextView balance;
Button btn_deposit,btn_draw;
EditText et_deposit,et_draw;

double getBalance(){
    double b=0;
    for (Operation operation:MainActivity.list){
        b=operation.getAmount()+b;
    }
    return b;
}

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);
Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
       AlertDialog.Builder builder = new AlertDialog.Builder(this);
        balance=findViewById(R.id.balance);
        btn_deposit=findViewById(R.id.deposit);
        btn_draw=findViewById(R.id.btn_draw);
        et_deposit=findViewById(R.id.et_deposit);
        et_draw=findViewById(R.id.et_draw);
        balance.setText(""+getBalance()+"$");
        btn_draw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_draw.getText().toString().isEmpty()){
                    et_draw.setError("fill this field");
                }else {
                    double l=Double.parseDouble(et_draw.getText().toString());
                   if (l>getBalance()){
                       builder.setMessage("Amount too high \n the amount must be less than "+getBalance()+"$")
                               .setCancelable(false)
                               .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                                   public void onClick(DialogInterface dialog, int id) {
                                       

                                   }
                               });

                       //Creating dialog box
                       AlertDialog alert = builder.create();
                       //Setting the title manually
                       alert.setTitle("Erreur");
                       alert.show();
                   }else {
                       MainActivity.list.add(new Operation(MainActivity.list.size()+1,Double.parseDouble(et_draw.getText().toString())*-1, java.time.LocalDate.now()));
                       balance.setText(""+getBalance()+"$");
                   }


                }
            }
        });
        btn_deposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_deposit.getText().toString().isEmpty()){
                    et_deposit.setError("fill this field");
                }else {

                    MainActivity.list.add(new Operation(MainActivity.list.size()+1,Double.parseDouble(et_deposit.getText().toString()),java.time.LocalDate.now()));
                    balance.setText(""+getBalance()+"$");
                }
            }
        });
    }
}
